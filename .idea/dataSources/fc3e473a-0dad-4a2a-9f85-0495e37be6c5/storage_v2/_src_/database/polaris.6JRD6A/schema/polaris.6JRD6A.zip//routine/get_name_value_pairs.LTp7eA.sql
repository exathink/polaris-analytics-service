create function get_name_value_pairs(organization integer)
  returns TABLE(pname text, name text, value text)
language plpgsql
as $$
DECLARE project RECORD;
  BEGIN
    FOR project in select projects.name as pname, properties->'ou' as ou from repos.projects  where organization_id=organization LOOP
    RETURN QUERY select project.pname::text as proj, * from jsonb_to_recordset(project.ou) as (name text, value text);
    END LOOP;
    RETURN;
  END;
$$;

