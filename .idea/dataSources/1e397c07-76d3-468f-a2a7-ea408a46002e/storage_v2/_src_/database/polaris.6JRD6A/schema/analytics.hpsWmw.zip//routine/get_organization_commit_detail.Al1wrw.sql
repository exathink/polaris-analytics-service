CREATE FUNCTION get_organization_commit_detail(org_key uuid, sample_threshold integer)
  RETURNS TABLE(organization text, organization_key uuid, repository text, commit_key text, commit_date timestamp without time zone, author_date timestamp without time zone, committer text, author text, commit_message text, num_parents integer, stats text)
LANGUAGE plpgsql
AS $$
DECLARE
  commit_count integer;

BEGIN
  SELECT * INTO STRICT commit_count FROM
    (
        SELECT count(commits.id)
          FROM
        repos.commits
        INNER JOIN
        repos.repositories ON commits.repository_id = repositories.id
        WHERE repositories.organization_key = org_key
  ) as cc;

  IF commit_count < sample_threshold THEN
    RETURN QUERY
    SELECT
      organizations.name::text as organization,
      org_key,
      repositories.name::text as repository,
      commits.key::text as commit_key,
      commits.commit_date,
      commits.author_date,
      authors.canonical_name::text as author,
      committers.canonical_name::text as committer,
      commits.commit_message::text,
      commits.num_parents,
      commits.stats::text
    FROM
      repos.organizations
      INNER JOIN repos.repositories ON organizations.organization_key = repositories.organization_key
      INNER JOIN repos.commits on  commits.repository_id = repositories.id
      INNER JOIN repos.contributor_aliases as authors on commits.author_alias_id = authors.id
      INNER JOIN repos.contributor_aliases as committers on commits.committer_alias_id = committers.id
      WHERE
        repositories.organization_key = org_key;
  ELSE
    CREATE TEMPORARY  TABLE organization_commits_sample_population
      ON COMMIT DROP
      AS SELECT commits.id as commit_id FROM
        repos.commits inner join
        repos.repositories on commits.repository_id = repositories.id
        WHERE repositories.organization_key=org_key;

    RETURN QUERY
    SELECT
      organizations.name::text as organization,
      org_key,
      repositories.name::text as repository,
      commits.key::text as commit_key,
      commits.commit_date,
      commits.author_date,
      authors.canonical_name::text as author,
      committers.canonical_name::text as committer,
      commits.commit_message::text,
      commits.num_parents,
      commits.stats::text
    FROM
      repos.organizations
      INNER JOIN repos.repositories ON organizations.organization_key = repositories.organization_key
      INNER JOIN repos.commits on  commits.repository_id = repositories.id
      INNER JOIN (
        SELECT commit_id
          FROM organization_commits_sample_population
          TABLESAMPLE BERNOULLI ((sample_threshold * 100)/(commit_count + 1))
      ) as commits_sample
      on commits_sample.commit_id = commits.id
      INNER JOIN repos.contributor_aliases as authors on commits.author_alias_id = authors.id
      INNER JOIN repos.contributor_aliases as committers on commits.committer_alias_id = committers.id
      WHERE
        repositories.organization_key = org_key;
  END IF;
END
$$;

