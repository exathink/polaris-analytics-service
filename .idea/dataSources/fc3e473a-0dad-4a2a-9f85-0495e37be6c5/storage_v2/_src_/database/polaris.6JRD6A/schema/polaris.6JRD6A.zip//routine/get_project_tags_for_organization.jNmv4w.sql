CREATE FUNCTION get_project_tags_for_organization(organization_name text)
  RETURNS TABLE(project text, tag text)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY 
  SELECT
    projects.name as project,
    jsonb_array_elements(projects.properties->'tags') as tag
  FROM
    repos.projects
    INNER JOIN repos.organizations on projects.organization_id = organizations.id
  WHERE organizations.name = organization_name
  and jsonb_typeof(projects.properties->'tags') = 'array';
END
$$;

