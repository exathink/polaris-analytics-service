CREATE FUNCTION get_organization_projects_summary(organization_name text)
  RETURNS TABLE(organization text, project text, project_group text, tags jsonb, description text, website text, issues_url text, repository text, earliest_commit timestamp without time zone, latest_commit timestamp without time zone, commit_count bigint, contributor_count bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    organization_name  AS organization,
    projects.name :: TEXT       AS project,
    projects.properties->>'project_group' AS project_group,
    projects.properties->'tags'              AS tags,
    projects.properties->>'description'  AS description,
    projects.properties->>'website'      AS website,
    projects.properties->>'issues_url'    AS issues_url,
    op_summary.repository :: TEXT    AS repository,
    op_summary.earliest_commit       AS earliest_commit,
    op_summary.latest_commit         AS latest_commit,
    op_summary.commit_count::BIGINT  AS commit_count,
    op_summary.contributor_count
  FROM
    (
      SELECT
        projects.id                             AS project_id,
        min(repositories.name)                  AS repository,
        min(repositories.earliest_commit)       AS earliest_commit,
        max(repositories.latest_commit)         AS latest_commit,
        sum(repositories.commit_count)          AS commit_count,
        count(DISTINCT contributor_alias_id)    AS contributor_count
      FROM
        repos.organizations
        INNER JOIN repos.projects ON organizations.id = projects.organization_id
        INNER JOIN repos.projects_repositories ON projects.id = projects_repositories.project_id
        INNER JOIN repos.repositories ON projects_repositories.repository_id = repositories.id
        INNER JOIN repos.repositories_contributor_aliases on repositories.id = repositories_contributor_aliases.repository_id
      WHERE
      organizations.name = organization_name
      GROUP BY projects.id
  ) AS op_summary
  INNER JOIN
    repos.projects on op_summary.project_id = projects.id;
END
$$;

