CREATE FUNCTION get_organization_contributor_summary(org_key uuid)
  RETURNS TABLE(organization text, organization_key uuid, repository text, num_contributors bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    min(organizations.name) as organization,
    org_key,
    min(repositories.name) as repository,
    count(distinct contributor_aliases.canonical_name) as num_contributors
  FROM
    repos.organizations
    INNER JOIN repos.repositories ON organizations.organization_key = repositories.organization_key
    INNER JOIN repos.repositories_contributor_aliases on repositories.id = repositories_contributor_aliases.repository_id
    INNER JOIN repos.contributor_aliases on repositories_contributor_aliases.contributor_alias_id = contributor_aliases.id
    WHERE organizations.organization_key = org_key
    GROUP BY repositories.id;
END;
$$;

