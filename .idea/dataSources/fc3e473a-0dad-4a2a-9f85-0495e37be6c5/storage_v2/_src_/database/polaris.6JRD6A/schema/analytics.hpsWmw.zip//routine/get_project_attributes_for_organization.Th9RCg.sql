CREATE FUNCTION get_project_attributes_for_organization(organization_name text)
  RETURNS TABLE(organization text, project text, description text, website text, issues text)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
    SELECT
      organizations.name::text as organization,
      projects.name::text as project,
      projects.properties->>'description'::text as description,
      projects.properties->>'website'::text as website,
      projects.properties->>'issues_url'::text as issues
    FROM
      repos.projects INNER JOIN repos.organizations on projects.organization_id = organizations.id
    WHERE
      organizations.name = organization_name;
END;
$$;

