CREATE FUNCTION get_repositories_without_projects(organization_name text)
  RETURNS TABLE(repository_id integer, name text)
LANGUAGE plpgsql
AS $$
BEGIN
RETURN QUERY
SELECT
  repositories.id as repository_id,
  repositories.name::text
FROM
  repos.organizations
  INNER JOIN repos.repositories ON repositories.organization_key = organizations.organization_key
  LEFT OUTER JOIN repos.projects_repositories ON repositories.id = projects_repositories.repository_id
WHERE organizations.name = organization_name
      AND project_id IS NULL;
END
$$;

