CREATE FUNCTION get_organization_commit_summary(org_key uuid)
  RETURNS TABLE(organization text, organization_key uuid, repository text, earliest_commit timestamp without time zone, latest_commit timestamp without time zone, commit_count bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    min(organizations.name) as organization,
    org_key,
    min(repositories.name) as repository,
    min(commit_date) as earliest_commit,
    max(commit_date) as latest_commit,
    count(commits.id) as commit_count
  FROM
    repos.organizations
    INNER JOIN repos.repositories ON organizations.organization_key = repositories.organization_key
    INNER JOIN repos.commits on repositories.id = commits.repository_id
    WHERE organizations.organization_key = org_key
    GROUP BY repositories.id;
END;
$$;

