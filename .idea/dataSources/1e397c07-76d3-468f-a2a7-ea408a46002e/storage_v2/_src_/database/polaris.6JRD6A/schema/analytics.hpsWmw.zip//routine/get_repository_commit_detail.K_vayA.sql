CREATE FUNCTION get_repository_commit_detail(org_key uuid, rep_id integer, br_id integer)
  RETURNS TABLE(organization text, organization_key uuid, repository text, branch text, commit_key text, commit_date timestamp without time zone, author_date timestamp without time zone, committer text, author text, commit_message text, num_parents integer, stats text)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    organizations.name::text as organization,
    org_key,
    repositories.name::text as repository,
    branches.name::text as branch,
    commits.key::text as commit_key,
    commits.commit_date,
    commits.author_date,
    authors.canonical_name::text as author,
    committers.canonical_name::text as committer,
    commits.commit_message::text,
    commits.num_parents,
    commits.stats::text
  FROM
    repos.organizations
    INNER JOIN repos.repositories ON organizations.organization_key = repositories.organization_key
    INNER JOIN repos.branches on repositories.id = branches.repository_id
    INNER JOIN repos.branch_commits on branches.id = branch_commits.branch_id
    INNER JOIN repos.commits on  branch_commits.commit_id = commits.id
    INNER JOIN repos.contributor_aliases as authors on commits.author_alias_id = authors.id
    INNER JOIN repos.contributor_aliases as committers on commits.committer_alias_id = committers.id
  WHERE
      organizations.organization_key=org_key and
      repositories.id = rep_id and
      branches.id = br_id;

END;
$$;

